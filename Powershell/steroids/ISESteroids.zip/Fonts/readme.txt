CUSTOM FONT SUPPORT
===================

If you place font files in this folder, they can be used in ISESteroids without the need to install them.

We added a number of useful open source fonts to this folder. You can add more fonts.

All fonts placed into this folder will show up in any font dialog displayed by ISESteroids. Fonts will be available in ISESteroids only unless you install the fonts with Administrator privileges.

Always make sure you do not violate any copyright attached to fonts. We took great care to review the copyright notices attached to the fonts we included. The copyright notices are kept with the fonts. 

Should you feel that we included a font in error, please let us know and we will remove it.

